package com.darshil.gaming;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.TextUtils;
import java.util.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(8,12,20), panel = Color.rgb(20,28,43), accent = Color.rgb(255,62,87);
    String[] brands = {"POCO","Redmi","Realme","Samsung","Vivo","OPPO","iQOO","OnePlus","Motorola","Google Pixel","Nothing","Infinix","Tecno","Xiaomi","Other / अन्य"};
    Map<String,String[]> models = new LinkedHashMap<>();
    LinearLayout page, settingsBox;
    Spinner brandSpinner, modelSpinner;
    EditText customModel;
    TextView dpiValue, status;
    SeekBar dpiBar, fireBar;
    Map<String,SeekBar> sensitivityBars = new LinkedHashMap<>();
    String[] sensitivityNames = {"General","Red Dot","2x Scope","4x Scope","Sniper Scope","Free Look"};
    android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        seedModels();
        buildUi();
    }

    void seedModels() {
        models.put("POCO", new String[]{"C75 5G","X6 Pro","M6 Pro","M6 5G","C65","F6","Other POCO"});
        models.put("Redmi", new String[]{"Note 13","Note 13 Pro","12 5G","13 5G","A3","13C","Other Redmi"});
        models.put("Realme", new String[]{"C55","C65","C67 5G","Narzo 70","12x 5G","P1","Other Realme"});
        models.put("Samsung", new String[]{"Galaxy A15","Galaxy A25","Galaxy M14","Galaxy M34","Galaxy S series","Other Samsung"});
        models.put("Vivo", new String[]{"Y28","T3x","T3","Y200","V series","Other Vivo"});
        models.put("OPPO", new String[]{"A3 Pro","A59 5G","F25 Pro","Reno series","Other OPPO"});
        models.put("iQOO", new String[]{"Z9x","Z9","Neo series","Other iQOO"});
        models.put("OnePlus", new String[]{"Nord CE 4 Lite","Nord CE 4","Nord series","Other OnePlus"});
        models.put("Motorola", new String[]{"G34","G54","Edge series","Other Motorola"});
        models.put("Google Pixel", new String[]{"Pixel 7a","Pixel 8a","Pixel series","Other Pixel"});
        models.put("Nothing", new String[]{"Phone (2a)","Phone series","Other Nothing"});
        models.put("Infinix", new String[]{"Hot series","Note series","GT series","Other Infinix"});
        models.put("Tecno", new String[]{"Spark series","Pova series","Camon series","Other Tecno"});
        models.put("Xiaomi", new String[]{"Xiaomi 13/14 series","Other Xiaomi"});
        models.put("Other / अन्य", new String[]{"मॉडल चुनें","Other"});
    }

    GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); d.setStroke(1, Color.rgb(43,55,76));
        return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, 4, 0, 4); return t;
    }
    LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    void addCard(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12)); v.setPadding(dp(15),dp(14),dp(15),dp(14));
        v.setBackground(shape(panel, dp(16))); page.addView(v, lp);
    }
    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        page = vertical(); page.setPadding(dp(16),dp(16),dp(16),dp(24)); scroll.addView(page); setContentView(scroll);

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("⌖",30,Color.WHITE,true); logo.setGravity(Gravity.CENTER); logo.setBackground(shape(accent,dp(14)));
        logo.setWidth(dp(52)); logo.setHeight(dp(52)); header.addView(logo);
        LinearLayout titleBox = vertical(); titleBox.setPadding(dp(12),0,0,0);
        titleBox.addView(text("DARSHIL GAMING",20,Color.WHITE,true));
        titleBox.addView(text("ALL-MOBILE SENSITIVITY GUIDE",11,accent,true)); header.addView(titleBox);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2); hp.setMargins(0,0,0,dp(18)); page.addView(header,hp);

        LinearLayout device = vertical();
        device.addView(text("अपना मोबाइल ब्रांड चुनें",16,Color.WHITE,true));
        brandSpinner = spinner(brands); device.addView(brandSpinner);
        device.addView(text("मॉडल चुनें",16,Color.WHITE,true));
        modelSpinner = spinner(models.get(brands[0])); device.addView(modelSpinner);
        customModel = new EditText(this); customModel.setSingleLine(true); customModel.setHint("अगर मॉडल सूची में नहीं है, तो लिखें"); customModel.setTextColor(Color.WHITE); customModel.setHintTextColor(Color.LTGRAY); customModel.setBackground(shape(bg,dp(10))); customModel.setPadding(dp(10),dp(8),dp(10),dp(8)); device.addView(customModel);
        TextView load = text("इस डिवाइस की प्रोफाइल लोड करें",14,Color.WHITE,true); load.setGravity(Gravity.CENTER); load.setPadding(0,dp(12),0,dp(12)); load.setBackground(shape(accent,dp(10))); device.addView(load);
        addCard(device);

        brandSpinner.setOnItemSelectedListener(new SimpleSelectListener(() -> {
            String brand = (String)brandSpinner.getSelectedItem();
            modelSpinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, models.get(brand)));
        }));
        load.setOnClickListener(v -> loadProfile());

        LinearLayout dpiCard = vertical();
        LinearLayout dpiRow = new LinearLayout(this); dpiRow.setGravity(Gravity.CENTER_VERTICAL);
        dpiRow.addView(text("DPI / Display size guide",16,Color.WHITE,true));
        dpiValue = text("445",20,accent,true); dpiRow.addView(dpiValue);
        dpiCard.addView(dpiRow);
        dpiBar = new SeekBar(this); dpiBar.setMax(280); dpiBar.setProgress(125); dpiCard.addView(dpiBar);
        dpiBar.setOnSeekBarChangeListener(new SimpleSeek(() -> dpiValue.setText(String.valueOf(320 + dpiBar.getProgress()))));
        dpiCard.addView(text("नोट: यह Android की वास्तविक DPI अपने आप नहीं बदलता। यह केवल आपकी चुनी हुई गाइड वैल्यू है।",12,Color.LTGRAY,false));
        addCard(dpiCard);

        settingsBox = vertical();
        settingsBox.addView(text("Sensitivity (0–200)",16,Color.WHITE,true));
        for (String name : sensitivityNames) {
            LinearLayout block = vertical();
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label = text(name,14,Color.WHITE,false); row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            TextView val = text("180",16,accent,true); row.addView(val); block.addView(row);
            SeekBar sb = new SeekBar(this); sb.setMax(200); sb.setProgress(name.equals("Sniper Scope")?100:180); block.addView(sb);
            sb.setOnSeekBarChangeListener(new SimpleSeek(() -> val.setText(String.valueOf(sb.getProgress()))));
            sensitivityBars.put(name,sb); settingsBox.addView(block);
        }
        addCard(settingsBox);

        LinearLayout fireCard = vertical();
        LinearLayout fr = new LinearLayout(this); fr.setGravity(Gravity.CENTER_VERTICAL);
        fr.addView(text("Fire Button Size",16,Color.WHITE,true)); fireValue = text("48%",20,accent,true); fr.addView(fireValue);
        fireCard.addView(fr);
        fireBar = new SeekBar(this); fireBar.setMax(40); fireBar.setProgress(18); fireCard.addView(fireBar);
        fireBar.setOnSeekBarChangeListener(new SimpleSeek(() -> fireValue.setText((30+fireBar.getProgress())+"%")));
        addCard(fireCard);

        TextView save = action("प्रोफाइल सेव करें"); page.addView(save, buttonParams());
        save.setOnClickListener(v -> { prefs.edit().putString(profileKey(), currentValues()).apply(); showStatus("इस डिवाइस की प्रोफाइल सेव हो गई।"); });
        TextView copy = action("सेटिंग्स कॉपी करें"); page.addView(copy, buttonParams());
        copy.setOnClickListener(v -> { ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("Darshil Gaming Settings", currentValues())); showStatus("सेटिंग्स कॉपी हो गईं।"); });
        TextView reset = action("डिफॉल्ट पर रीसेट करें"); reset.setBackground(shape(Color.rgb(27,36,53),dp(12))); page.addView(reset, buttonParams());
        reset.setOnClickListener(v -> resetValues());

        status = text("",13,Color.rgb(117,230,162),false); page.addView(status);
        TextView note = text("यह केवल सेटिंग्स गाइड है। यह गेम को नियंत्रित नहीं करती, ऑटो-हेडशॉट नहीं लगाती और किसी भी सेटिंग से परफेक्ट हेडशॉट की गारंटी नहीं होती। अलग फोन और गेम अपडेट पर परिणाम बदल सकते हैं।",12,Color.LTGRAY,false);
        note.setPadding(0,dp(12),0,dp(4)); page.addView(note);
    }

    TextView fireValue;
    Spinner spinner(String[] items) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); s.setAdapter(a); return s;
    }
    TextView action(String label) {
        TextView t = text(label,15,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setPadding(0,dp(14),0,dp(14)); t.setBackground(shape(accent,dp(12))); return t;
    }
    LinearLayout.LayoutParams buttonParams() { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(10)); return p; }
    String profileKey() {
        String b=(String)brandSpinner.getSelectedItem(), m=(String)modelSpinner.getSelectedItem();
        String typed=customModel.getText().toString().trim();
        return (b+"_"+(typed.isEmpty()?m:typed)).replaceAll("[^A-Za-z0-9_]", "_");
    }
    String currentValues() {
        StringBuilder s=new StringBuilder("DARSHIL GAMING SETTINGS\nDevice: ").append(profileKey())
            .append("\nDPI guide: ").append(320+dpiBar.getProgress()).append("\n");
        for(String n:sensitivityNames) s.append(n).append(": ").append(sensitivityBars.get(n).getProgress()).append("\n");
        s.append("Fire Button: ").append(30+fireBar.getProgress()).append("%");
        return s.toString();
    }
    void loadProfile() {
        String saved=prefs.getString(profileKey(),null);
        if(saved==null){ resetValues(); showStatus("इस डिवाइस के लिए शुरुआती प्रोफाइल दिखाई गई है।"); return; }
        try {
            String[] lines=saved.split("\n");
            for(String line:lines) {
                String[] pair=line.split(": ",2); if(pair.length<2) continue;
                String k=pair[0],v=pair[1].replace("%","");
                if(k.equals("DPI guide")) dpiBar.setProgress(Math.max(0,Math.min(280,Integer.parseInt(v)-320)));
                else if(k.equals("Fire Button")) fireBar.setProgress(Math.max(0,Math.min(40,Integer.parseInt(v)-30)));
                else if(sensitivityBars.containsKey(k)) sensitivityBars.get(k).setProgress(Integer.parseInt(v));
            }
            showStatus("सेव की हुई प्रोफाइल लोड हो गई।");
        } catch(Exception e) { showStatus("प्रोफाइल लोड नहीं हो सकी।"); }
    }
    void resetValues() {
        dpiBar.setProgress(125); fireBar.setProgress(18);
        for(String n:sensitivityNames) sensitivityBars.get(n).setProgress(n.equals("Sniper Scope")?100:180);
        showStatus("डिफॉल्ट वैल्यू रीसेट हो गईं।");
    }
    void showStatus(String s) { status.setText(s); }
    interface Action { void run(); }
    class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        Action a; SimpleSeek(Action x){a=x;} public void onProgressChanged(SeekBar b,int p,boolean u){a.run();}
        public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
    }
    class SimpleSelectListener implements AdapterView.OnItemSelectedListener {
        Action a; SimpleSelectListener(Action x){a=x;} public void onItemSelected(AdapterView<?> p,View v,int pos,long id){a.run();}
        public void onNothingSelected(AdapterView<?> p){}
    }
}
