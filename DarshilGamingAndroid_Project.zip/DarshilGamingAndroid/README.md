# Darshil Gaming Android project

This is an Android Studio source project for a general mobile sensitivity guide.

## Features
- Brand and model selection (sample device lists)
- DPI/display-size guide slider (does not change Android system DPI)
- Sensitivity sliders and fire-button size guide
- Save/load profile per selected device, copy settings, reset

## Build
1. Install Android Studio (current stable) on a computer.
2. Open this folder as a project.
3. Let Gradle sync and install any requested Android SDK components.
4. Run on a test phone.
5. For Google Play, use Build > Generate Signed Bundle / APK > Android App Bundle, then follow Play Console requirements.

This source project is not a compiled APK or Play-ready signed AAB. Values are generic starting points, not verified perfect settings. It does not automate aiming or interact with a game.
